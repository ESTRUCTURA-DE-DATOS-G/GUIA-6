package Logica;

import Interfaz.JuegoHanoi;

public class TorresHanoi {

    public static void main(String[] args) {                
        JuegoHanoi juego = new JuegoHanoi();
        juego.setVisible(true);
    }
    
}
