package Logica;

public class ColasVO {

    private int[] elementos;
    private int tamaño;
    private int capacidad;
    private int frente;
    private int finalCola;

    public ColasVO(int capacidad) {
        this.elementos = new int[capacidad];
        this.capacidad = capacidad;
        this.tamaño = 0;
        this.frente = 0;
        this.finalCola = -1;
    }

    public int[] getElementos() {
        return elementos;
    }

    public void setElementos(int[] elementos) {
        this.elementos = elementos;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getFrente() {
        return frente;
    }

    public void setFrente(int frente) {
        this.frente = frente;
    }

    public int getFinalCola() {
        return finalCola;
    }

    public void setFinalCola(int finalCola) {
        this.finalCola = finalCola;
    }
}