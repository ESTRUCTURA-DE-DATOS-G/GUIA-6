package expresionpostfija;

import java.util.EmptyStackException;
import java.util.Stack;
import javax.swing.JOptionPane;

public class EvalPostfija {

    private Stack<String> operandos = new <Character>Stack();
    private float a, b, z, resultadoExpresion;

    public EvalPostfija(float a, float b, float z) {
        this.a = a;
        this.b = b;
        this.z = z;
    }

    public EvalPostfija() {
        this.a = 0;
        this.b = 0;
        this.z = 0;
        this.resultadoExpresion = 0;

    }

    public Stack<String> getOperandos() {
        return operandos;
    }

    public void setOperandos(Stack<String> operandos) {
        this.operandos = operandos;
    }

    public float getResultadoExpresion() {
        return resultadoExpresion;
    }

    public void setResultadoExpresion(float resultadoExpresion) {
        this.resultadoExpresion = resultadoExpresion;
    }

    public float getA() {
        return a;
    }

    public void setA(float a) {
        this.a = a;
    }

    public float getB() {
        return b;
    }

    public void setB(float b) {
        this.b = b;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    public void evaluar(ExpresionPostFija objPostfija) {
        
        
        for (int i = 0; i < objPostfija.getExpresionPos().length; i++) {
             
            if (validarNumero(objPostfija.getExpresionPos()[i]) == true) {
                operandos.push(Character.toString(objPostfija.getExpresionPos()[i]));

            } else if (objPostfija.getExpresionPos()[i] != Character.MIN_VALUE) {
                z = 0;
                b = Float.parseFloat(operandos.pop());
                a = Float.parseFloat(operandos.pop());
                z = encontrarOperador(objPostfija.getExpresionPos()[i], a, b);
                operandos.push(Float.toString(z));
            }
             

        }

        objPostfija.setResultado(Float.parseFloat(operandos.peek()));
        System.out.println(Float.parseFloat(operandos.peek()));

    }

    public boolean validarNumero(char caracter) {
        return caracter == '0' || caracter == '1' || caracter == '2' || caracter == '3' || caracter == '4' || caracter == '5'
                || caracter == '6' || caracter == '7' || caracter == '8' || caracter == '9';
    }

    public float encontrarOperador(char caracter, float a, float b) {
        float result = 0;
        switch (caracter) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                result = a / b;
                break;
            default:
                result = (float) Math.pow(a, b);
                break;
        }

        return result;

    }

}
