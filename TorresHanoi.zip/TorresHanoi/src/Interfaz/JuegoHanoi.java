package Interfaz;

import Logica.Nodo;
import Logica.Pila;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class JuegoHanoi extends javax.swing.JFrame {

    FondoPanel fondo = new FondoPanel();

    int contNumMov = 0;
    Pila PilaTorreA;
    Pila PilaTorreB;
    Pila PilaTorreC;

    DefaultTableModel ModeloTablaTorreA, ModeloTablaTorreB, ModeloTablaTorreC;

    int Objetivo = 0;
    double NumMinMov = 0;

    public JuegoHanoi() {
        this.setContentPane(fondo);
        initComponents();
        setLocationRelativeTo(this);
        setIconImage(getIconImage());

        ModeloTablaTorreA = (DefaultTableModel) tbl_A.getModel();
        ModeloTablaTorreA.setRowCount(Objetivo);//20

        ModeloTablaTorreB = (DefaultTableModel) tbl_B.getModel();
        ModeloTablaTorreB.setRowCount(Objetivo);//20

        ModeloTablaTorreC = (DefaultTableModel) tbl_C.getModel();
        ModeloTablaTorreC.setRowCount(Objetivo);//20

        DefaultTableCellRenderer renderA = new DefaultTableCellRenderer();
        renderA.setHorizontalAlignment(SwingConstants.CENTER);
        tbl_A.getColumnModel().getColumn(0).setCellRenderer(renderA);

        DefaultTableCellRenderer renderB = new DefaultTableCellRenderer();
        renderB.setHorizontalAlignment(SwingConstants.CENTER);
        tbl_B.getColumnModel().getColumn(0).setCellRenderer(renderB);

        DefaultTableCellRenderer renderC = new DefaultTableCellRenderer();
        renderC.setHorizontalAlignment(SwingConstants.CENTER);
        tbl_C.getColumnModel().getColumn(0).setCellRenderer(renderC);
    }

    private void Limpiar() {
        contNumMov = 0;
        NumMinMov = 0;

        txt_Discos.setText(String.valueOf(Objetivo));
    }

    private void PresentarCantMov() {
        contNumMov++;
        lb_Movimientos.setText(String.valueOf(contNumMov));
    }

    private void Reiniciar() {
        try {

            if (!lb_MovimientosMinimos.getText().equals("")) {
                Limpiar();
                Iniciar();
            }

        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }

    private void Iniciar() {

        try {
            PilaTorreA = new Pila();
            PilaTorreB = new Pila();
            PilaTorreC = new Pila();

            Objetivo = Integer.parseInt(txt_Discos.getText());

            NumMinMov = Math.pow(2, Objetivo) - 1;

            lb_Movimientos.setText(String.valueOf(contNumMov));
            lb_MovimientosMinimos.setText(String.valueOf(String.format("%.0f", NumMinMov)));

            for (int x = Objetivo; x >= 1; x--) {
                Nodo Plataforma = new Nodo();

                String Disco = "";

                for (int y = x; y > 0; y--) {
                    Disco += "#";
                }

                Plataforma.setDato(Disco);
                PilaTorreA.Push(Plataforma);
            }

            PresentarTorreA();
            PresentarTorreB();
            PresentarTorreC();

        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }

    private void PresentarTorreA() {

        ((DefaultTableModel) tbl_A.getModel()).setRowCount(0);

        ModeloTablaTorreA.setRowCount(Objetivo);//20

        Nodo nodo;

        int RowDisco = (Objetivo - PilaTorreA.getContNodo());//20

        if (PilaTorreA.getContNodo() > 0) {
            for (nodo = PilaTorreA.getCabeza(); nodo.getAbajo() != null; nodo = nodo.getAbajo()) {

                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreA.insertRow(RowDisco, VectorNormal);
                RowDisco++;
            }
            if (nodo.getAbajo() == null) {
                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreA.insertRow(RowDisco, VectorNormal);
            }
        }
        tbl_A.setModel(ModeloTablaTorreA);
        ModeloTablaTorreA.setRowCount(Objetivo);//20
    }

    private void PresentarTorreB() {

        ((DefaultTableModel) tbl_B.getModel()).setRowCount(0);

        ModeloTablaTorreB.setRowCount(Objetivo);//20

        Nodo nodo;

        int RowDisco = (Objetivo - PilaTorreB.getContNodo());//20

        if (PilaTorreB.getContNodo() > 0) {
            for (nodo = PilaTorreB.getCabeza(); nodo.getAbajo() != null; nodo = nodo.getAbajo()) {

                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreB.insertRow(RowDisco, VectorNormal);
                RowDisco++;
            }
            if (nodo.getAbajo() == null) {
                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreB.insertRow(RowDisco, VectorNormal);
            }
        }
        tbl_B.setModel(ModeloTablaTorreB);
        ModeloTablaTorreB.setRowCount(Objetivo);//20
    }

    private void PresentarTorreC() {

        ((DefaultTableModel) tbl_C.getModel()).setRowCount(0);

        ModeloTablaTorreC.setRowCount(Objetivo);//20

        Nodo nodo;

        int RowDisco = (Objetivo - PilaTorreC.getContNodo());//20

        if (PilaTorreC.getContNodo() > 0) {
            for (nodo = PilaTorreC.getCabeza(); nodo.getAbajo() != null; nodo = nodo.getAbajo()) {

                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreC.insertRow(RowDisco, VectorNormal);
                RowDisco++;
            }
            if (nodo.getAbajo() == null) {
                String[] VectorNormal = {nodo.getDato()};
                ModeloTablaTorreC.insertRow(RowDisco, VectorNormal);
            }
        }
        tbl_C.setModel(ModeloTablaTorreC);
        ModeloTablaTorreC.setRowCount(Objetivo);//20
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_A = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_B = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_C = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_TorreAB = new javax.swing.JButton();
        btn_TorreAC = new javax.swing.JButton();
        btn_TorreBA = new javax.swing.JButton();
        btn_TorreBC = new javax.swing.JButton();
        btn_TorreCA = new javax.swing.JButton();
        btn_TorreCB = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txt_Discos = new javax.swing.JTextField();
        btn_Iniciar = new javax.swing.JButton();
        btn_Reiniciar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        lb_Movimientos = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lb_MovimientosMinimos = new javax.swing.JLabel();
        btn_Resolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TORRES DE HANOI JUEGO");

        tbl_A.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Torre A"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_A.setAutoscrolls(false);
        tbl_A.setFocusable(false);
        tbl_A.setRowSelectionAllowed(false);
        jScrollPane1.setViewportView(tbl_A);
        if (tbl_A.getColumnModel().getColumnCount() > 0) {
            tbl_A.getColumnModel().getColumn(0).setResizable(false);
        }

        tbl_B.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                " Torre B"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_B.setAutoscrolls(false);
        tbl_B.setFocusable(false);
        tbl_B.setRowSelectionAllowed(false);
        jScrollPane2.setViewportView(tbl_B);
        if (tbl_B.getColumnModel().getColumnCount() > 0) {
            tbl_B.getColumnModel().getColumn(0).setResizable(false);
        }

        tbl_C.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Torre C"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_C.setAutoscrolls(false);
        tbl_C.setFocusable(false);
        tbl_C.setRowSelectionAllowed(false);
        jScrollPane3.setViewportView(tbl_C);
        if (tbl_C.getColumnModel().getColumnCount() > 0) {
            tbl_C.getColumnModel().getColumn(0).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Monotype Corsiva", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("TORRES DE HANOI");

        jLabel5.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TORRE B");

        btn_TorreAB.setBackground(new java.awt.Color(153, 102, 255));
        btn_TorreAB.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreAB.setText("TORRE B");
        btn_TorreAB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreABActionPerformed(evt);
            }
        });

        btn_TorreAC.setBackground(new java.awt.Color(51, 153, 255));
        btn_TorreAC.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreAC.setText("TORRE C");
        btn_TorreAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreACActionPerformed(evt);
            }
        });

        btn_TorreBA.setBackground(new java.awt.Color(255, 102, 102));
        btn_TorreBA.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreBA.setText("TORRE A");
        btn_TorreBA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreBAActionPerformed(evt);
            }
        });

        btn_TorreBC.setBackground(new java.awt.Color(51, 153, 255));
        btn_TorreBC.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreBC.setText("TORRE C");
        btn_TorreBC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreBCActionPerformed(evt);
            }
        });

        btn_TorreCA.setBackground(new java.awt.Color(255, 102, 102));
        btn_TorreCA.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreCA.setText("TORRE A");
        btn_TorreCA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreCAActionPerformed(evt);
            }
        });

        btn_TorreCB.setBackground(new java.awt.Color(153, 102, 255));
        btn_TorreCB.setForeground(new java.awt.Color(255, 255, 255));
        btn_TorreCB.setText("TORRE B");
        btn_TorreCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TorreCBActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jLabel6.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TORRE C");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel6)
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6))
        );

        jLabel4.setFont(new java.awt.Font("Sitka Text", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TORRE A");

        jLabel2.setFont(new java.awt.Font("Sitka Text", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Indique el # de discos:");

        txt_Discos.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        txt_Discos.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        btn_Iniciar.setBackground(new java.awt.Color(0, 0, 0));
        btn_Iniciar.setForeground(new java.awt.Color(255, 255, 255));
        btn_Iniciar.setText("JUGAR");
        btn_Iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_IniciarActionPerformed(evt);
            }
        });

        btn_Reiniciar.setBackground(new java.awt.Color(0, 0, 0));
        btn_Reiniciar.setForeground(new java.awt.Color(255, 255, 255));
        btn_Reiniciar.setText("REINICIAR");
        btn_Reiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ReiniciarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("# Movimientos");

        lb_Movimientos.setForeground(new java.awt.Color(255, 255, 255));
        lb_Movimientos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("# Movimientos Minimos");

        lb_MovimientosMinimos.setForeground(new java.awt.Color(255, 255, 255));
        lb_MovimientosMinimos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btn_Resolver.setBackground(new java.awt.Color(0, 0, 0));
        btn_Resolver.setForeground(new java.awt.Color(255, 255, 255));
        btn_Resolver.setText("RESOLVER");
        btn_Resolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ResolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(txt_Discos, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_Iniciar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btn_TorreAB, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn_TorreAC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btn_TorreBA, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_TorreBC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(72, 72, 72))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lb_Movimientos, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btn_Reiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(94, 94, 94))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btn_TorreCA, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_TorreCB, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btn_Resolver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(68, 68, 68))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(lb_MovimientosMinimos, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(330, 330, 330))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(135, 135, 135)
                        .addComponent(jLabel4)
                        .addGap(770, 770, 770))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_TorreBC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_TorreBA, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_TorreAC, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_TorreAB, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_TorreCB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_TorreCA, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_Iniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Reiniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Resolver, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(lb_Movimientos, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(txt_Discos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7))))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lb_MovimientosMinimos, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_IniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_IniciarActionPerformed
        Iniciar();
    }//GEN-LAST:event_btn_IniciarActionPerformed

    private void btn_ReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ReiniciarActionPerformed
        Reiniciar();
    }//GEN-LAST:event_btn_ReiniciarActionPerformed

    private void MoverA_B() {

        try {

            if (PilaTorreA.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreA.Peek());

                if (PilaTorreB.getContNodo() > 0) {

                    if (Plataforma.getDato().compareTo(PilaTorreB.Peek()) > 0) {
                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreA.Pop();
                PilaTorreB.Push(Plataforma);

                PresentarTorreA();
                PresentarTorreB();
                PresentarCantMov();
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }


    private void btn_TorreABActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreABActionPerformed
        MoverA_B();
    }//GEN-LAST:event_btn_TorreABActionPerformed

    private void MoverA_C() {
        try {

            if (PilaTorreA.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreA.Peek());

                if (PilaTorreC.getContNodo() > 0) {
                    if (Plataforma.getDato().compareTo(PilaTorreC.Peek()) > 0) {

                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreA.Pop();
                PilaTorreC.Push(Plataforma);

                PresentarTorreA();
                PresentarTorreC();
                PresentarCantMov();

                if (PilaTorreC.getContNodo() == Objetivo && contNumMov == NumMinMov) {

                    JOptionPane.showMessageDialog(null, "Felicidades, pudiste hacerlo en el minimo de movimientos",
                            "FELICIDADES", JOptionPane.INFORMATION_MESSAGE);

                } else if (PilaTorreC.getContNodo() == Objetivo && contNumMov != NumMinMov) {

                    JOptionPane.showMessageDialog(null, "Lograste el objetivo, pero no en el minimo de movimientos, animo",
                            "FELICIDADES", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }

    }
    private void btn_TorreACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreACActionPerformed
        MoverA_C();
    }//GEN-LAST:event_btn_TorreACActionPerformed

    private void MoverB_A() {

        try {

            if (PilaTorreB.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreB.Peek());

                if (PilaTorreA.getContNodo() > 0) {

                    if (Plataforma.getDato().compareTo(PilaTorreA.Peek()) > 0) {
                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreB.Pop();
                PilaTorreA.Push(Plataforma);

                PresentarTorreA();
                PresentarTorreB();
                PresentarCantMov();
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }
    private void btn_TorreBAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreBAActionPerformed
        MoverB_A();
    }//GEN-LAST:event_btn_TorreBAActionPerformed
    private void MoverB_C() {
        try {

            if (PilaTorreB.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreB.Peek());

                if (PilaTorreC.getContNodo() > 0) {
                    if (Plataforma.getDato().compareTo(PilaTorreC.Peek()) > 0) {

                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreB.Pop();
                PilaTorreC.Push(Plataforma);

                PresentarTorreB();
                PresentarTorreC();
                PresentarCantMov();

                if (PilaTorreC.getContNodo() == Objetivo && contNumMov == NumMinMov) {

                    JOptionPane.showMessageDialog(null, "Felicidades, pudiste hacerlo en el minimo de movimientos",
                            "FELICIDADES", JOptionPane.INFORMATION_MESSAGE);

                } else if (PilaTorreC.getContNodo() == Objetivo && contNumMov != NumMinMov) {

                    JOptionPane.showMessageDialog(null, "Lograste el objetivo, pero no en el minimo de movimientos, animo",
                            "FELICIDADES", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }
    private void btn_TorreBCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreBCActionPerformed
        MoverB_C();
    }//GEN-LAST:event_btn_TorreBCActionPerformed
    private void MoverC_A() {

        try {

            if (PilaTorreC.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreC.Peek());

                if (PilaTorreA.getContNodo() > 0) {

                    if (Plataforma.getDato().compareTo(PilaTorreA.Peek()) > 0) {
                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreC.Pop();
                PilaTorreA.Push(Plataforma);

                PresentarTorreA();
                PresentarTorreC();
                PresentarCantMov();
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }
    private void btn_TorreCAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreCAActionPerformed
        MoverC_A();
    }//GEN-LAST:event_btn_TorreCAActionPerformed
    private void MoverC_B() {

        try {

            if (PilaTorreC.getContNodo() > 0) {
                Nodo Plataforma = new Nodo();

                Plataforma.setDato(PilaTorreC.Peek());

                if (PilaTorreB.getContNodo() > 0) {

                    if (Plataforma.getDato().compareTo(PilaTorreB.Peek()) > 0) {
                        JOptionPane.showMessageDialog(null, "No se puede poner un disco de mayor tamaño sobre uno menor",
                                "ERROR", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }

                PilaTorreC.Pop();
                PilaTorreB.Push(Plataforma);

                PresentarTorreB();
                PresentarTorreC();
                PresentarCantMov();
            }
        } catch (Exception E) {
            System.out.println("Error: " + E.getMessage());
        }
    }
    private void btn_TorreCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TorreCBActionPerformed
        MoverC_B();
    }//GEN-LAST:event_btn_TorreCBActionPerformed

    boolean Stop = false;
    
    private void MoverPlataforma(Pila Origen, Pila Destino){
        if(Stop == false){
            Nodo Plataforma = new Nodo();
            
            Plataforma.setDato(Origen.Peek());
            Origen.Pop();
            
            Destino.Push(Plataforma);
            
            PresentarTorreA();
            PresentarTorreB();
            PresentarTorreC();
            PresentarCantMov();
            
            JOptionPane panel = new JOptionPane("Paso # " + lb_Movimientos.getText()+ "\n\n ¿Desea Continuar?", JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION);
            JDialog dialog = panel.createDialog("PASOS ");
            
            dialog.setLocation(493, 397);
            
            dialog.setVisible(true);
            
            int option = (int) panel.getValue();
            
            if(option == JOptionPane.NO_OPTION){
                Stop = true;
            } 
        }
    }
    
    private void Resolver(int n, Pila Origen, Pila Auxiliar, Pila Destino){
        
        if(n == 1){
            
            MoverPlataforma(Origen, Destino);
        }else{
            Resolver(n-1, Origen, Destino, Auxiliar);
            MoverPlataforma(Origen, Destino);
            
            Resolver(n-1, Auxiliar, Origen, Destino);
        }
    }
    
    
    
    private void btn_ResolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ResolverActionPerformed
        if(!lb_MovimientosMinimos.getText().equals("") && PilaTorreC.getContNodo() != Objetivo){
            
            Reiniciar();
            Stop = false;
            
            Resolver(Objetivo, PilaTorreA, PilaTorreB, PilaTorreC);
        }
    }//GEN-LAST:event_btn_ResolverActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Iniciar;
    private javax.swing.JButton btn_Reiniciar;
    private javax.swing.JButton btn_Resolver;
    private javax.swing.JButton btn_TorreAB;
    private javax.swing.JButton btn_TorreAC;
    private javax.swing.JButton btn_TorreBA;
    private javax.swing.JButton btn_TorreBC;
    private javax.swing.JButton btn_TorreCA;
    private javax.swing.JButton btn_TorreCB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lb_Movimientos;
    private javax.swing.JLabel lb_MovimientosMinimos;
    private javax.swing.JTable tbl_A;
    private javax.swing.JTable tbl_B;
    private javax.swing.JTable tbl_C;
    private javax.swing.JTextField txt_Discos;
    // End of variables declaration//GEN-END:variables

    class FondoPanel extends JPanel {

        private Image imagen;

        @Override
        public void paint(Graphics g) {
            imagen = new ImageIcon(getClass().getResource("/Imagenes/Fondo.jpeg")).getImage();
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);

            setOpaque(false);

            super.paint(g);
        }
    }

    //Icono JFrame
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Imagenes/Icono.png"));
        return retValue;
    }

}
