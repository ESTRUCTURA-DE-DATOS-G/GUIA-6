package Logica;

public class Pila extends Nodo{
    
    //Contador Nodo para poder ir generando los nodos necesarios
    private int contNodo = 0;
    private Nodo cabeza;

    public int getContNodo() {
        return contNodo;
    }

    public void setContNodo(int contNodo) {
        this.contNodo = contNodo;
    }

    public Nodo getCabeza() {
        return cabeza;
    }

    public void setCabeza(Nodo cabeza) {
        this.cabeza = cabeza;
    }
    
    //Metodo Push para apilar
    public void Push(Nodo N){
        contNodo++;
        if(cabeza == null){
            cabeza = N;
        } else {
            N.setAbajo(cabeza);
            cabeza.setArriba(N);
            
            cabeza = N;
        }
    }
    
    //Metodo pop para desapilar
    public void Pop(){
        
        if(contNodo > 0){
            contNodo--;
            
            cabeza = cabeza.getAbajo();
        }
    }
    
    //Metodo peek para obtener el dato de la cabeza
    public String Peek(){
        return cabeza.getDato();
    }
}
