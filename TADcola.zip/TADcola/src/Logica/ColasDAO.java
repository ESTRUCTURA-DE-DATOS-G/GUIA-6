package Logica;

import javax.swing.JOptionPane;

public class ColasDAO {
    private ColasVO cola;
    private int capacidad;
    private int[] elementos;
    private int tamaño;
    private int frente;
    private int finalCola;

    public ColasDAO(ColasVO cola) {
        this.cola = cola;
        this.capacidad = cola.getCapacidad();
        this.elementos = cola.getElementos();
        this.tamaño = cola.getTamaño();
        this.frente = cola.getFrente();
        this.finalCola = cola.getFinalCola();
    }

    public void menuOpciones(String dato) {
        switch (dato) {
            case "Encolar":
                encolarElemento();
                break;
            case "Desencolar":
                desencolarElemento();
                break;
            case "Mostrar frente":
                mostrarFrente();
                break;
            case "Mostrar tamaño":
                mostrarTamaño();
                break;
            case "Mostrar cola":
                mostrarCola();
                break;
            default:
                System.out.println("Opción no válida");
        }
    }
    
    private int obtenerElemento() {
        while (true) {
            try {
                String elementoStr = JOptionPane.showInputDialog(null, "Ingrese el elemento a encolar:", "Elemento", JOptionPane.QUESTION_MESSAGE);
                if (elementoStr == null)
                    this.dispose();
                return Integer.parseInt(elementoStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void encolarElemento() {
        if (estaLlena()) {
            JOptionPane.showMessageDialog(null, "La cola está llena. No se puede encolar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int elemento = obtenerElemento();
        finalCola = (finalCola + 1) % capacidad;
        elementos[finalCola] = elemento;
        tamaño++;
    }

    private int desencolarElemento() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "La cola está vacía. No se puede desencolar.", "Error", JOptionPane.ERROR_MESSAGE);
            return -1;
        }
        int elementoDesencolado = elementos[frente];
        frente = (frente + 1) % capacidad;
        tamaño--;
        return elementoDesencolado;
    }

    public void mostrarFrente() {
        if (estaVacia()) {
            JOptionPane.showMessageDialog(null, "La cola está vacía. No hay frente para mostrar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(null, "Frente de la cola: " + elementos[frente], "Frente de la cola", JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarTamaño() {
        JOptionPane.showMessageDialog(null, "Tamaño de la cola: " + tamaño, "Tamaño de la cola", JOptionPane.INFORMATION_MESSAGE);
    }


public void mostrarCola() {
    int[] elementos = cola.getElementos();
    StringBuilder sb = new StringBuilder("Elementos de la cola:\n");
    for (int i = 0; i < tamaño; i++) {
        sb.append(elementos[(frente + i) % capacidad]).append(" ");
    }
    JOptionPane.showMessageDialog(null, sb.toString(), "Elementos de la cola", JOptionPane.INFORMATION_MESSAGE);
}
 
   public boolean estaVacia() {
        return tamaño == 0;
    }

    public boolean estaLlena() {
        return tamaño == capacidad;
    }

    private void dispose() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}