package Logica;
import javax.swing.JOptionPane;

public class CircularDAO {

    private static class Nodo {
        int dato;
        Nodo siguiente;

        public Nodo(int dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    private Nodo cabeza;

    public CircularDAO() {
        this.cabeza = null;
    }

    public void inicializarConTamano(int tamano) {
        if (tamano <= 0) {
            JOptionPane.showMessageDialog(null, "El tamaño debe ser un número positivo mayor que cero.");
            return;
        }
        for (int i = 1; i <= tamano; i++) {
            int dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dato del nodo " + i + ":"));
            insertarAlFinal(dato);
        }
        JOptionPane.showMessageDialog(null, "La lista se ha inicializado con éxito con " + tamano + " nodos.");
    }

    public int solicitarTamanoInicial() {
        int tamano = 0;
        boolean entradaValida = false;
        do {
            try {
                String input = JOptionPane.showInputDialog(null, "Ingrese el tamaño inicial de los nodos:");
                tamano = Integer.parseInt(input);
                if (tamano > 0) {
                    entradaValida = true;
                } else {
                    JOptionPane.showMessageDialog(null, "El tamaño debe ser un número positivo mayor que cero.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Por favor, ingrese un número válido.");
            }
        } while (!entradaValida);
        return tamano;
    }

    public void insertarAlInicio(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            nuevoNodo.siguiente = cabeza;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != cabeza) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
            nuevoNodo.siguiente = cabeza;
            cabeza = nuevoNodo;
        }
    }

    public void insertarAlFinal(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            nuevoNodo.siguiente = cabeza;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != cabeza) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
            nuevoNodo.siguiente = cabeza;
        }
    }

    public void insertarDespuesDe(int dato, int valor) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Nodo nuevoNodo = new Nodo(dato);
        Nodo temp = cabeza;
        do {
            if (temp.dato == valor) {
                nuevoNodo.siguiente = temp.siguiente;
                temp.siguiente = nuevoNodo;
                return;
            }
            temp = temp.siguiente;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "El valor no se encuentra en la lista");
    }

    public void eliminarPorValor(int valor) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Nodo temp = cabeza;
        Nodo prev = null;
        do {
            if (temp.dato == valor) {
                if (temp == cabeza) {
                    cabeza = temp.siguiente;
                    Nodo ultimo = temp;
                    while (ultimo.siguiente != temp) {
                        ultimo = ultimo.siguiente;
                    }
                    ultimo.siguiente = cabeza;
                } else {
                    prev.siguiente = temp.siguiente;
                }
                JOptionPane.showMessageDialog(null, "Nodo con valor " + valor + " eliminado");
                return;
            }
            prev = temp;
            temp = temp.siguiente;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "El valor no se encuentra en la lista");
    }

    public void eliminarPorPosicion(int posicion) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Nodo temp = cabeza;
        Nodo prev = null;
        int contador = 1;
        do {
            if (contador == posicion) {
                if (temp == cabeza) {
                    cabeza = temp.siguiente;
                    Nodo ultimo = temp;
                    while (ultimo.siguiente != temp) {
                        ultimo = ultimo.siguiente;
                    }
                    ultimo.siguiente = cabeza;
                } else {
                    prev.siguiente = temp.siguiente;
                }
                JOptionPane.showMessageDialog(null, "Nodo en la posición " + posicion + " eliminado");
                return;
            }
            prev = temp;
            temp = temp.siguiente;
            contador++;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "La posición especificada no existe en la lista");
    }

    public void actualizarValor(int antiguoValor, int nuevoValor) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Nodo temp = cabeza;
        do {
            if (temp.dato == antiguoValor) {
                temp.dato = nuevoValor;
                JOptionPane.showMessageDialog(null, "Valor actualizado correctamente");
                return;
            }
            temp = temp.siguiente;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "El valor especificado no se encuentra en la lista");
    }

    public int buscarPosicion(int valor) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return -1;
        }
        Nodo temp = cabeza;
        int posicion = 0;
        do {
            if (temp.dato == valor) {
                return posicion;
            }
            temp = temp.siguiente;
            posicion++;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "El valor especificado no se encuentra en la lista");
        return -1;
    }

    public void mostrar() {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Nodo temp = cabeza;
        StringBuilder lista = new StringBuilder();
        do {
            lista.append(temp.dato).append(" ");
            temp = temp.siguiente;
        } while (temp != cabeza);
        JOptionPane.showMessageDialog(null, "Elementos de la lista: " + lista.toString());
    }

    public void ordenarAscendente() {
        if (cabeza == null || cabeza.siguiente == cabeza) {
            JOptionPane.showMessageDialog(null, "La lista está vacía o solo tiene un elemento. No es necesario ordenar.");
            return;
        }

        Nodo actual, siguiente;
        boolean intercambiado;

        do {
            intercambiado = false;
            actual = cabeza;
            siguiente = cabeza.siguiente;

            do {
                if (actual.dato > siguiente.dato) {
                    int temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;
                    intercambiado = true;
                }

                actual = siguiente;
                siguiente = siguiente.siguiente;
            } while (siguiente != cabeza);

        } while (intercambiado);

        JOptionPane.showMessageDialog(null, "La lista ha sido ordenada en orden ascendente.");
    }

    public void menuOpciones(String dato) {
        switch (dato) {
            case "Insertar nodo al inicio":
                int datoInicio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dato a insertar al inicio:"));
                insertarAlInicio(datoInicio);
                break;
            case "Insertar nodo al final":
                int datoFinal = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dato a insertar al final:"));
                insertarAlFinal(datoFinal);
                break;
            case "Insertar nodo después de un valor":
                int datoDespuesDe = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dato a insertar:"));
                int valorDespuesDe = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor después del cual desea insertar el dato:"));
                insertarDespuesDe(datoDespuesDe, valorDespuesDe);
                break;
            case "Eliminar nodo por valor":
                int valorEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor del nodo a eliminar:"));
                eliminarPorValor(valorEliminar);
                break;
            case "Eliminar nodo por posición":
                int posicionEliminar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la posición del nodo a eliminar:"));
                eliminarPorPosicion(posicionEliminar);
                break;
            case "Actualizar valor de un nodo":
                int antiguoValor = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor del nodo a actualizar:"));
                int nuevoValor = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el nuevo valor:"));
                actualizarValor(antiguoValor, nuevoValor);
                break;
            case "Buscar posición de un valor":
                int valorBuscar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor a buscar:"));
                int posicion = buscarPosicion(valorBuscar);
                if (posicion != -1) {
                    JOptionPane.showMessageDialog(null, "El valor " + valorBuscar + " se encuentra en la posición " + posicion);
                }
                break;
            case "Mostrar lista":
                mostrar();
                break;
            case "":
                ordenarAscendente();
                break;
            case "Ordenar lista en orden ascendente":
                ordenarAscendente();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, seleccione una opción válida.");
                break;
        }
    }

}
